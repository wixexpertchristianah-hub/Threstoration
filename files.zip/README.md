# T.H Restorations — Classic Vehicle Specialists

A single-page website for **T.H Restorations**, a classic vehicle restoration workshop based in Buxton, UK. Built with HTML, Tailwind CSS, and vanilla JavaScript.

---

## Features

- **Responsive design** — works on desktop and mobile
- **Smooth scroll animations** — elements fade in as you scroll
- **Services section** — Nut & Bolt Restoration, Weld Repairs, Vehicle Repairs
- **Before & After gallery** — showcasing real project transformations (Escort RS Turbo, MK1/MK2 Focus RS, Subaru WRX)
- **Portfolio gallery** — recent works grid
- **Restoration process** — step-by-step methodology
- **Contact form** — submits enquiries via Supabase edge function
- **Stats section** — years of experience, restorations completed

---

## Tech Stack

| Technology | Purpose |
|---|---|
| HTML5 | Structure |
| [Tailwind CSS](https://tailwindcss.com/) (CDN) | Styling |
| [Lucide Icons](https://lucide.dev/) (CDN) | Icons |
| [Google Fonts](https://fonts.google.com/) | DM Serif Display + Manrope |
| Vanilla JavaScript | Animations & form handling |
| [Supabase](https://supabase.com/) | Contact form backend |

---

## Getting Started

No build step required. Just open `index.html` in a browser.

```bash
git clone https://github.com/your-username/th-restorations.git
cd th-restorations
open index.html
```

---

## Configuration

The contact form posts to a Supabase edge function. Before deploying, replace the `{{PROJECT_ID}}` placeholder in `index.html` with your actual Supabase project ID:

```js
projectId: '{{PROJECT_ID}}',  // ← replace this
```

---

## Project Structure

```
th-restorations/
└── index.html    # Single-page site (all HTML, CSS config, and JS)
└── README.md
```

---

## Contact

**T.H Restorations**
📍 Buxton, United Kingdom
📞 +44 7477 858986
✉️ info@threstoration.co.uk
